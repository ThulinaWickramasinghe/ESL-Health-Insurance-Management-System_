<div id="sidebar">
                <div class="img-profile">
                    <img src="./img/user_icon.png" alt="adminLogo" id="adminLogo">

                </div>
                <ul>

                    <a href="./create-healthplans.php"><li>Create Helth Plan</li></a> 
                    
                    <a href="./all-plans.php"><li>All Health Plans</li></a>
                
                    <a href="" target="_blank" style="color: black; text-decoration: none;"><li >Staff</li></a>
                </ul>

            </div>